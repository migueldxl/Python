import os
from flask import Flask, render_template, request, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy  # feito: Importar SQLAlchemy

app = Flask(__name__)
app.secret_key = "chave_secreta_loja_tech"

# feito: Configurar SQLALCHEMY_DATABASE_URI para loja.db
basedir = os.path.abspath(os.path.dirname(__file__))
app.config['SQLALCHEMY_DATABASE_URI'] = f"sqlite:///{os.path.join(basedir, 'loja.db')}"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# feito: Criar db = SQLAlchemy(app)
db = SQLAlchemy(app)

# feito: Completar a classe Produto (Model)
class Produto(db.Model):
    __tablename__ = "produtos"
    
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(120), nullable=False)
    categoria = db.Column(db.String(60), nullable=False)
    preco = db.Column(db.Float, nullable=False)
    estoque = db.Column(db.Integer, nullable=False, default=0)

    def __repr__(self):
        return f"<Produto {self.nome}>"


# feito: Rota Principal - Listar produtos (ordenar por nome)
@app.route('/')
def lista_produtos():
    # SQLAlchemy 2.0 usa db.select() para consultas ordenadas
    stmt = db.select(Produto).order_by(Produto.nome)
    produtos = db.session.scalars(stmt).all()
    return render_template('lista.html', produtos=produtos)


# feito: Rota Cadastrar - Formulário + salvar novo produto
@app.route('/cadastrar', methods=['GET', 'POST'])
def cadastrar():
    if request.method == 'POST':
        nome = request.form.get('nome', '').strip()
        categoria = request.form.get('categoria', '').strip()
        preco_raw = request.form.get('preco', '0')
        estoque_raw = request.form.get('estoque', '0')

        # feito: Validar campos obrigatórios e regras de negócio
        if not nome or not categoria or not preco_raw:
            flash("Nome, categoria e preço são obrigatórios!", "danger")
            return render_template('formulario.html', produto=None, dados=request.form)

        try:
            preco = float(preco_raw)
            estoque = int(estoque_raw)
            
            if estoque < 0:
                flash("O estoque não pode ser negativo!", "danger")
                return render_template('formulario.html', produto=None, dados=request.form)
                
        except ValueError:
            flash("Preço e Estoque devem conter valores numéricos válidos!", "danger")
            return render_template('formulario.html', produto=None, dados=request.form)

        # Criando o novo objeto
        novo_produto = Produto(
            nome=nome, 
            categoria=categoria, 
            preco=preco, 
            estoque=estoque
        )
        
        # feito: add + commit no cadastro
        db.session.add(novo_produto)
        db.session.commit()
        
        flash("Produto cadastrado com sucesso!", "success")
        return redirect(url_for('lista_produtos'))

    return render_template('formulario.html', produto=None, dados={})


# feito: Rota Editar - Formulário + atualizar dados
@app.route('/editar/<int:produto_id>', methods=['GET', 'POST'])
def editar(produto_id):
    # feito: buscar produto por ID (get)
    produto = db.session.get(Produto, produto_id)
    if not produto:
        flash("Produto não encontrado!", "danger")
        return redirect(url_for('lista_produtos'))

    if request.method == 'POST':
        nome = request.form.get('nome', '').strip()
        categoria = request.form.get('categoria', '').strip()
        preco_raw = request.form.get('preco', '0')
        estoque_raw = request.form.get('estoque', '0')

        # Validações idênticas ao cadastro
        if not nome or not categoria or not preco_raw:
            flash("Nome, categoria e preço são obrigatórios!", "danger")
            return render_template('formulario.html', produto=produto, dados=request.form)

        try:
            preco = float(preco_raw)
            estoque = int(estoque_raw)
            
            if estoque < 0:
                flash("O estoque não pode ser negativo!", "danger")
                return render_template('formulario.html', produto=produto, dados=request.form)
                
        except ValueError:
            flash("Valores numéricos inválidos!", "danger")
            return render_template('formulario.html', produto=produto, dados=request.form)

        # feito: atualizar dados do objeto existente
        produto.nome = nome
        produto.categoria = categoria
        produto.preco = preco
        produto.estoque = estoque

        db.session.commit()
        flash("Produto atualizado com sucesso!", "success")
        return redirect(url_for('lista_produtos'))

    # Se for GET, envia o produto para preencher os campos do formulário
    return render_template('formulario.html', produto=produto, dados={})


# feito: Rota Excluir - Remover produto do banco
@app.route('/excluir/<int:produto_id>', methods=['POST'])
def excluir(produto_id):
    produto = db.session.get(Produto, produto_id)
    if produto:
        # feito: delete + commit na exclusão
        db.session.delete(produto)
        db.session.commit()
        flash("Produto excluído com sucesso!", "success")
    else:
        flash("Produto não encontrado.", "danger")
        
    return redirect(url_for('lista_produtos'))


# feito: Chamar db.create_all() dentro do contexto do app
with app.app_context():
    db.create_all()

if __name__ == '__main__':
    app.run(debug=True)