from flask import Blueprint, render_template
from flask_sqlalchemy import SQLAlchemy

from models import Jogador, db  

dashboard_bp = Blueprint("dashboard", __name__)


@dashboard_bp.route("/")
def index():
    total = db.session.execute(db.select(db.func.count(Jogador.id))).scalar_one()

    return render_template(
        "index.html",
        total_jogadores=total,
    )