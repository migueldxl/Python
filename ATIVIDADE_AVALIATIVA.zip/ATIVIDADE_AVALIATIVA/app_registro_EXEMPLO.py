import os
from flask import Flask
from models import db
from controllers.figurinhas_controller import figurinhas_bp

# 1. Cria a aplicação Flask e aponta para a pasta de templates
app = Flask(__name__, 
            template_folder="views/templates", 
            static_folder="views/static")

# 2. Configura o banco de dados local (SQLite)
BASE_DIR = os.path.abspath(os.path.dirname(__file__))
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///" + os.path.join(BASE_DIR, "dados.db")
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

# 3. Inicializa o banco de dados
db.init_app(app)

# 4. Registra as rotas das figurinhas
app.register_blueprint(figurinhas_bp)

# 5. Cria as tabelas no banco de dados automaticamente
with app.app_context():
    db.create_all()

# Rota para não dar erro ao acessar a raiz "/"
@app.route("/")
def home():
    from flask import redirect, url_for
    return redirect(url_for("figurinhas.index"))

if __name__ == "__main__":
    app.run(debug=True)